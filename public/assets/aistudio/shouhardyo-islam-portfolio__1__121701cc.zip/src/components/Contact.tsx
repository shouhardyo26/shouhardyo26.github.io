import { useState } from 'react';
import {
  Mail,
  Phone,
  MessageCircle,
  Copy,
  Check,
  Send,
  Facebook,
  Instagram,
  ArrowUpRight,
} from 'lucide-react';
import { Language, ContactFormData } from '../types';
import { TRANSLATIONS } from '../utils/translations';
import { validateContactForm, formatMailtoUrl } from '../utils/validation';

interface ContactProps {
  language: Language;
}

export default function Contact({ language }: ContactProps) {
  const t = TRANSLATIONS[language];

  const [copiedType, setCopiedType] = useState<'email' | 'phone' | null>(null);

  const [formData, setFormData] = useState<ContactFormData>({
    name: '',
    email: '',
    subject: '',
    message: '',
  });

  const [errors, setErrors] = useState<Partial<Record<keyof ContactFormData, string>>>({});
  const [submitted, setSubmitted] = useState(false);

  const handleCopy = (text: string, type: 'email' | 'phone') => {
    navigator.clipboard.writeText(text);
    setCopiedType(type);
    setTimeout(() => setCopiedType(null), 2500);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    if (errors[name as keyof ContactFormData]) {
      setErrors((prev) => ({ ...prev, [name]: undefined }));
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const result = validateContactForm(formData);
    if (!result.isValid) {
      setErrors(result.errors);
      return;
    }

    setSubmitted(true);
    // Real submission mechanism via mailto protocol
    const mailtoLink = formatMailtoUrl(formData);
    window.location.href = mailtoLink;

    setTimeout(() => {
      setFormData({ name: '', email: '', subject: '', message: '' });
      setSubmitted(false);
    }, 4000);
  };

  return (
    <section id="contact" className="py-12 lg:py-16 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="max-w-3xl mb-8 sm:mb-10">
          <p className="text-xs uppercase tracking-widest font-bold text-[#50BFFF] mb-1.5">
            {t.contact.label}
          </p>
          <h2 className="font-heading text-2xl sm:text-3xl lg:text-4xl font-extrabold tracking-tight text-white dark:text-white text-slate-900 mb-2">
            {t.contact.heading}
          </h2>
          <p className="text-sm sm:text-base leading-relaxed text-slate-300 dark:text-slate-300 text-slate-700">
            {t.contact.description}
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 lg:gap-8 items-start">
          {/* Left Column: Direct Contact Info Cards */}
          <div className="lg:col-span-5 space-y-3">
            {/* Email Card */}
            <div className="rounded-xl p-3.5 sm:p-4.5 bg-[#0B0B17]/80 dark:bg-[#0B0B17]/80 bg-white/90 backdrop-blur-md border border-white/10 dark:border-white/10 border-slate-200 shadow-sm">
              <div className="flex items-center justify-between mb-1.5">
                <div className="flex items-center gap-2.5">
                  <div className="p-2 rounded-lg bg-[#50BFFF]/10 text-[#50BFFF]">
                    <Mail className="w-4 h-4" />
                  </div>
                  <div>
                    <p className="text-xs text-slate-400 dark:text-slate-400 text-slate-500 font-medium">
                      {t.contact.emailLabel}
                    </p>
                    <a
                      href="mailto:shouhardyoislam@gmail.com"
                      className="text-xs sm:text-sm font-bold text-white dark:text-white text-slate-900 hover:text-[#50BFFF] transition-colors break-all"
                    >
                      shouhardyoislam@gmail.com
                    </a>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => handleCopy('shouhardyoislam@gmail.com', 'email')}
                  className="p-1.5 rounded-lg bg-white/5 dark:bg-white/5 bg-slate-100 hover:bg-white/10 text-slate-300 dark:text-slate-300 text-slate-700 transition-colors"
                  aria-label="Copy email"
                >
                  {copiedType === 'email' ? (
                    <Check className="w-3.5 h-3.5 text-[#A1E342]" />
                  ) : (
                    <Copy className="w-3.5 h-3.5" />
                  )}
                </button>
              </div>
              {copiedType === 'email' && (
                <p className="text-xs text-[#A1E342] mt-1 font-medium">{t.contact.copySuccess}</p>
              )}
            </div>

            {/* Phone Card */}
            <div className="rounded-xl p-3.5 sm:p-4.5 bg-[#0B0B17]/80 dark:bg-[#0B0B17]/80 bg-white/90 backdrop-blur-md border border-white/10 dark:border-white/10 border-slate-200 shadow-sm">
              <div className="flex items-center justify-between mb-1.5">
                <div className="flex items-center gap-2.5">
                  <div className="p-2 rounded-lg bg-[#A1E342]/10 text-[#A1E342]">
                    <Phone className="w-4 h-4" />
                  </div>
                  <div>
                    <p className="text-xs text-slate-400 dark:text-slate-400 text-slate-500 font-medium">
                      {t.contact.phoneLabel}
                    </p>
                    <a
                      href="tel:+8801319873020"
                      className="text-xs sm:text-sm font-bold text-white dark:text-white text-slate-900 hover:text-[#A1E342] transition-colors"
                    >
                      +880 1319-873020
                    </a>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => handleCopy('+8801319873020', 'phone')}
                  className="p-1.5 rounded-lg bg-white/5 dark:bg-white/5 bg-slate-100 hover:bg-white/10 text-slate-300 dark:text-slate-300 text-slate-700 transition-colors"
                  aria-label="Copy phone number"
                >
                  {copiedType === 'phone' ? (
                    <Check className="w-3.5 h-3.5 text-[#A1E342]" />
                  ) : (
                    <Copy className="w-3.5 h-3.5" />
                  )}
                </button>
              </div>
              {copiedType === 'phone' && (
                <p className="text-xs text-[#A1E342] mt-1 font-medium">{t.contact.copySuccess}</p>
              )}
            </div>

            {/* WhatsApp Card */}
            <a
              href="http://wa.me/+8801319873020"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center justify-between p-3.5 sm:p-4.5 rounded-xl bg-[#0B0B17]/80 dark:bg-[#0B0B17]/80 bg-white/90 backdrop-blur-md border border-white/10 dark:border-white/10 border-slate-200 shadow-sm hover:border-emerald-500/40 group transition-all"
            >
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-lg bg-emerald-500/10 text-emerald-400">
                  <MessageCircle className="w-4 h-4" />
                </div>
                <div>
                  <p className="text-xs text-slate-400 dark:text-slate-400 text-slate-500 font-medium">
                    {t.contact.whatsappLabel}
                  </p>
                  <p className="text-sm sm:text-base font-bold text-white dark:text-white text-slate-900 group-hover:text-emerald-400 transition-colors">
                    +880 1319-873020
                  </p>
                </div>
              </div>
              <ArrowUpRight className="w-5 h-5 text-slate-500 group-hover:text-emerald-400 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
            </a>

            {/* Social Connection Cards (Facebook & Instagram only) */}
            <div className="grid grid-cols-2 gap-4 pt-2">
              <a
                href="https://www.facebook.com/shouhardyo.islam.9"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-between p-4 rounded-xl bg-[#0B0B17]/60 dark:bg-[#0B0B17]/60 bg-white/70 border border-white/10 dark:border-white/10 border-slate-200 hover:border-[#1877F2]/40 transition-all group"
              >
                <div className="flex items-center gap-2.5">
                  <Facebook className="w-4 h-4 text-[#1877F2]" />
                  <span className="text-xs font-semibold text-white dark:text-white text-slate-800">
                    Facebook
                  </span>
                </div>
                <ArrowUpRight className="w-4 h-4 text-slate-500 group-hover:text-[#1877F2] transition-colors" />
              </a>

              <a
                href="https://www.instagram.com/myself_shouhardyo_20/"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-between p-4 rounded-xl bg-[#0B0B17]/60 dark:bg-[#0B0B17]/60 bg-white/70 border border-white/10 dark:border-white/10 border-slate-200 hover:border-[#E1306C]/40 transition-all group"
              >
                <div className="flex items-center gap-2.5">
                  <Instagram className="w-4 h-4 text-[#E1306C]" />
                  <span className="text-xs font-semibold text-white dark:text-white text-slate-800">
                    Instagram
                  </span>
                </div>
                <ArrowUpRight className="w-4 h-4 text-slate-500 group-hover:text-[#E1306C] transition-colors" />
              </a>
            </div>
          </div>

          {/* Right Column: Functional Contact Form */}
          <div className="lg:col-span-7">
            <form
              onSubmit={handleSubmit}
              noValidate
              className="rounded-xl p-5 sm:p-6 bg-[#0B0B17]/80 dark:bg-[#0B0B17]/80 bg-white/95 backdrop-blur-md border border-white/10 dark:border-white/10 border-slate-200 shadow-lg space-y-3.5"
            >
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                {/* Name Field */}
                <div>
                  <label
                    htmlFor="contact-name"
                    className="block text-xs font-semibold text-slate-300 dark:text-slate-300 text-slate-700 mb-1"
                  >
                    {t.contact.form.nameLabel} <span className="text-[#A1E342]">*</span>
                  </label>
                  <input
                    id="contact-name"
                    type="text"
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    placeholder={t.contact.form.namePlaceholder}
                    className={`w-full px-3.5 py-2 rounded-lg bg-white/5 dark:bg-white/5 bg-slate-50 border ${
                      errors.name ? 'border-rose-500' : 'border-white/10 dark:border-white/10 border-slate-300'
                    } text-white dark:text-white text-slate-900 text-xs sm:text-sm placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-[#50BFFF] transition-colors`}
                  />
                  {errors.name && (
                    <p className="text-xs text-rose-400 mt-1">{errors.name}</p>
                  )}
                </div>

                {/* Email Field */}
                <div>
                  <label
                    htmlFor="contact-email"
                    className="block text-xs font-semibold text-slate-300 dark:text-slate-300 text-slate-700 mb-1"
                  >
                    {t.contact.form.emailLabel} <span className="text-[#A1E342]">*</span>
                  </label>
                  <input
                    id="contact-email"
                    type="email"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    placeholder={t.contact.form.emailPlaceholder}
                    className={`w-full px-3.5 py-2 rounded-lg bg-white/5 dark:bg-white/5 bg-slate-50 border ${
                      errors.email ? 'border-rose-500' : 'border-white/10 dark:border-white/10 border-slate-300'
                    } text-white dark:text-white text-slate-900 text-xs sm:text-sm placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-[#50BFFF] transition-colors`}
                  />
                  {errors.email && (
                    <p className="text-xs text-rose-400 mt-1">{errors.email}</p>
                  )}
                </div>
              </div>

              {/* Subject Field */}
              <div>
                <label
                  htmlFor="contact-subject"
                  className="block text-xs font-semibold text-slate-300 dark:text-slate-300 text-slate-700 mb-1"
                >
                  {t.contact.form.subjectLabel}
                </label>
                <input
                  id="contact-subject"
                  type="text"
                  name="subject"
                  value={formData.subject}
                  onChange={handleChange}
                  placeholder={t.contact.form.subjectPlaceholder}
                  className="w-full px-3.5 py-2 rounded-lg bg-white/5 dark:bg-white/5 bg-slate-50 border border-white/10 dark:border-white/10 border-slate-300 text-white dark:text-white text-slate-900 text-xs sm:text-sm placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-[#50BFFF] transition-colors"
                />
              </div>

              {/* Message Field */}
              <div>
                <label
                  htmlFor="contact-message"
                  className="block text-xs font-semibold text-slate-300 dark:text-slate-300 text-slate-700 mb-1"
                >
                  {t.contact.form.messageLabel} <span className="text-[#A1E342]">*</span>
                </label>
                <textarea
                  id="contact-message"
                  name="message"
                  rows={3}
                  value={formData.message}
                  onChange={handleChange}
                  placeholder={t.contact.form.messagePlaceholder}
                  className={`w-full px-3.5 py-2 rounded-lg bg-white/5 dark:bg-white/5 bg-slate-50 border ${
                    errors.message ? 'border-rose-500' : 'border-white/10 dark:border-white/10 border-slate-300'
                  } text-white dark:text-white text-slate-900 text-xs sm:text-sm placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-[#50BFFF] transition-colors resize-none`}
                />
                {errors.message && (
                  <p className="text-xs text-rose-400 mt-1">{errors.message}</p>
                )}
              </div>

              {/* Submission Button */}
              <button
                type="submit"
                disabled={submitted}
                className="w-full py-2.5 px-5 rounded-lg text-xs sm:text-sm font-semibold text-white bg-gradient-to-r from-[#7656E8] to-[#50BFFF] hover:from-[#6646d8] hover:to-[#38bdf8] shadow-[0_4px_14px_rgba(118,86,232,0.3)] transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-75"
              >
                {submitted ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-[#A1E342]" />
                    <span>{t.contact.form.sendingBtn}</span>
                  </>
                ) : (
                  <>
                    <Send className="w-3.5 h-3.5" />
                    <span>{t.contact.form.submitBtn}</span>
                  </>
                )}
              </button>

              {submitted && (
                <div className="p-2.5 rounded-lg bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs text-center">
                  {t.contact.form.successMsg}
                </div>
              )}
            </form>
          </div>
        </div>
      </div>
    </section>
  );
}
