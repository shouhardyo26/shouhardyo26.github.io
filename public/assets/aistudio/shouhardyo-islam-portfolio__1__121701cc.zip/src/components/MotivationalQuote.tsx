import { Quote } from 'lucide-react';
import { Language } from '../types';

interface MotivationalQuoteProps {
  language: Language;
}

export default function MotivationalQuote({ language }: MotivationalQuoteProps) {
  return (
    <section className="py-8 lg:py-10 relative overflow-hidden">
      {/* Cinematic dark background & subtle blue/purple lights */}
      <div
        className="pointer-events-none absolute inset-0 bg-gradient-to-b from-transparent via-[#7656E8]/10 to-transparent"
        aria-hidden="true"
      />
      <div
        className="pointer-events-none absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[350px] h-[200px] bg-[#50BFFF]/10 rounded-full blur-[80px]"
        aria-hidden="true"
      />

      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center">
        <div className="inline-flex items-center justify-center p-1.5 rounded-lg bg-white/5 dark:bg-white/5 bg-slate-100 border border-white/10 dark:border-white/10 border-slate-200 mb-3">
          <Quote className="w-4 h-4 text-[#A1E342]" />
        </div>

        <blockquote className="space-y-2">
          {language === 'bn' ? (
            <p className="font-bangla text-lg sm:text-xl lg:text-2xl font-semibold leading-relaxed text-white dark:text-white text-slate-900 max-w-2xl mx-auto">
              "স্বপ্ন সেটা নয় যা তুমি ঘুমিয়ে দেখ,{' '}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#50BFFF] via-[#A1E342] to-[#7656E8] underline decoration-[#50BFFF]/40 underline-offset-6">
                স্বপ্ন সেটাই যা তোমাকে ঘুমোতে দেয় না।
              </span>
              "
            </p>
          ) : (
            <p className="font-heading italic text-lg sm:text-xl lg:text-2xl font-medium leading-relaxed text-white dark:text-white text-slate-900 max-w-2xl mx-auto">
              "Dream is not that which you see while sleeping,{' '}
              <span className="not-italic font-bold text-transparent bg-clip-text bg-gradient-to-r from-[#50BFFF] via-[#A1E342] to-[#7656E8] underline decoration-[#50BFFF]/40 underline-offset-6">
                it is something that does not let you sleep.
              </span>
              "
            </p>
          )}

          <footer className="pt-1.5">
            <cite className="not-italic text-xs font-bold tracking-widest uppercase text-[#50BFFF]">
              — {language === 'bn' ? 'সৌহার্দ্য' : 'Shouhardyo'}
            </cite>
          </footer>
        </blockquote>
      </div>
    </section>
  );
}
