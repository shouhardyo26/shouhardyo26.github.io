import { Compass, Lightbulb, TrendingUp, Sparkles } from 'lucide-react';
import { Language } from '../types';
import { GOAL_CARDS, TRANSLATIONS } from '../utils/translations';

interface FutureVisionProps {
  language: Language;
}

export default function FutureVision({ language }: FutureVisionProps) {
  const t = TRANSLATIONS[language];

  const goalIcons = [
    <Compass key="1" className="w-4 h-4 text-[#50BFFF]" />,
    <Lightbulb key="2" className="w-4 h-4 text-[#A1E342]" />,
    <TrendingUp key="3" className="w-4 h-4 text-[#7656E8]" />,
  ];

  return (
    <section className="py-10 lg:py-12 relative overflow-hidden">
      {/* Subtle background ambient orb */}
      <div
        className="pointer-events-none absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[420px] h-[250px] bg-[#7656E8]/10 dark:bg-[#7656E8]/10 rounded-full blur-[100px]"
        aria-hidden="true"
      />

      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 lg:gap-10 items-center">
          {/* Left: Inspiring Personal Statement */}
          <div className="lg:col-span-6 space-y-3">
            <p className="text-[11px] uppercase tracking-widest font-bold text-[#7656E8] dark:text-[#50BFFF]">
              {t.futureVision.label}
            </p>
            <h2 className="font-heading text-xl sm:text-2xl lg:text-3xl font-extrabold tracking-tight text-white dark:text-white text-slate-900">
              {t.futureVision.heading}
            </h2>

            <div className="space-y-2.5 text-xs sm:text-sm leading-relaxed text-slate-300 dark:text-slate-300 text-slate-700">
              {t.futureVision.statement.split('\n\n').map((para, i) => (
                <p key={i}>{para}</p>
              ))}
            </div>

            {/* Closing statement */}
            <div className="p-3 sm:p-3.5 rounded-xl bg-gradient-to-r from-white/[0.06] to-white/[0.02] dark:from-white/[0.06] dark:to-white/[0.02] bg-slate-100 border border-white/10 dark:border-white/10 border-slate-200">
              <p className="text-xs sm:text-[13px] font-semibold text-[#A1E342] dark:text-[#A1E342] text-slate-900 italic">
                "{t.futureVision.closing}"
              </p>
            </div>
          </div>

          {/* Right: 3 Goal Cards (01 LEARN, 02 CREATE, 03 GROW) */}
          <div className="lg:col-span-6 space-y-2.5 sm:space-y-3">
            {GOAL_CARDS.map((card, idx) => {
              const title = language === 'bn' ? card.titleBn : card.titleEn;
              const desc = language === 'bn' ? card.descBn : card.descEn;

              return (
                <div
                  key={card.number}
                  className="group relative rounded-xl p-3 sm:p-3.5 bg-[#0B0B17]/80 dark:bg-[#0B0B17]/80 bg-white/90 backdrop-blur-md border border-white/10 dark:border-white/10 border-slate-200 shadow-sm hover:border-white/20 dark:hover:border-white/25 hover:border-slate-300 transition-all duration-300 hover:translate-x-1"
                >
                  <div className="flex items-start gap-3 sm:gap-3.5">
                    <span className="font-heading font-extrabold text-lg sm:text-xl text-slate-500 dark:text-slate-500 text-slate-400 group-hover:text-[#50BFFF] transition-colors">
                      {card.number}
                    </span>

                    <div className="flex-1">
                      <div className="flex items-center justify-between mb-1">
                        <h3 className="font-heading text-sm sm:text-base font-bold tracking-wide text-white dark:text-white text-slate-900">
                          {title}
                        </h3>
                        <div className="p-1.5 rounded-lg bg-white/5 dark:bg-white/5 bg-slate-100">
                          {goalIcons[idx]}
                        </div>
                      </div>
                      <p className="text-xs leading-relaxed text-slate-400 dark:text-slate-400 text-slate-600">
                        {desc}
                      </p>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}
