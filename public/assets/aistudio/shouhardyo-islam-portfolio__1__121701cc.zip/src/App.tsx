/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from 'react';
import { Language, Theme } from './types';
import CustomCursor from './components/CustomCursor';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import About from './components/About';
import Education from './components/Education';
import FutureVision from './components/FutureVision';
import Skills from './components/Skills';
import BeyondTheDesk from './components/BeyondTheDesk';
import WhatIDo from './components/WhatIDo';
import MotivationalQuote from './components/MotivationalQuote';
import Contact from './components/Contact';
import Footer from './components/Footer';
import CVModal from './components/CVModal';

export default function App() {
  const [language, setLanguage] = useState<Language>(() => {
    const saved = localStorage.getItem('portfolio_lang');
    return saved === 'bn' ? 'bn' : 'en';
  });

  const [theme, setTheme] = useState<Theme>(() => {
    const saved = localStorage.getItem('portfolio_theme');
    return saved === 'light' ? 'light' : 'dark';
  });

  const [cvModalOpen, setCvModalOpen] = useState(false);
  const [scrollProgress, setScrollProgress] = useState(0);

  // Sync language with localStorage
  const handleLanguageChange = (lang: Language) => {
    setLanguage(lang);
    localStorage.setItem('portfolio_lang', lang);
  };

  // Sync theme with HTML class and localStorage
  const handleThemeToggle = () => {
    const newTheme: Theme = theme === 'dark' ? 'light' : 'dark';
    setTheme(newTheme);
    localStorage.setItem('portfolio_theme', newTheme);
  };

  useEffect(() => {
    const root = document.documentElement;
    if (theme === 'dark') {
      root.classList.add('dark');
      root.classList.remove('light');
    } else {
      root.classList.remove('dark');
      root.classList.add('light');
    }
  }, [theme]);

  // Track scroll progress
  useEffect(() => {
    const handleScroll = () => {
      const totalScroll = document.documentElement.scrollHeight - window.innerHeight;
      if (totalScroll > 0) {
        const currentProgress = (window.scrollY / totalScroll) * 100;
        setScrollProgress(currentProgress);
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <div className="min-h-screen bg-[#080B18] dark:bg-[#080B18] bg-slate-50 text-[#F5F5FA] dark:text-[#F5F5FA] text-slate-900 transition-colors duration-300 relative selection:bg-[#7656E8]/30 selection:text-white">
      {/* Top Reading Scroll Progress Indicator */}
      <div
        className="fixed top-0 left-0 h-1 bg-gradient-to-r from-[#7656E8] via-[#50BFFF] to-[#A1E342] z-50 transition-all duration-100 ease-out"
        style={{ width: `${scrollProgress}%` }}
        aria-hidden="true"
      />

      {/* Desktop-Only BMW Sports Car Cursor */}
      <CustomCursor />

      {/* 01. Navigation */}
      <Navbar
        language={language}
        onLanguageChange={handleLanguageChange}
        theme={theme}
        onThemeToggle={handleThemeToggle}
      />

      <main>
        {/* 02. Hero */}
        <Hero language={language} onOpenCvModal={() => setCvModalOpen(true)} />

        {/* 03. About Me */}
        <About language={language} />

        {/* 04. Education & Learning Journey */}
        <Education language={language} onOpenCvModal={() => setCvModalOpen(true)} />

        {/* 05. Future Vision & Personal Goals */}
        <FutureVision language={language} />

        {/* 06 & 07. Skills & Expertise + Software & Technology */}
        <Skills language={language} />

        {/* 08. Beyond the Desk */}
        <BeyondTheDesk language={language} />

        {/* 09. What I Do & Explore */}
        <WhatIDo language={language} />

        {/* 10. Personal Motivational Quote */}
        <MotivationalQuote language={language} />

        {/* 11. Contact */}
        <Contact language={language} />
      </main>

      {/* 12. Footer */}
      <Footer language={language} onOpenCvModal={() => setCvModalOpen(true)} />

      {/* Verified CV Preview & Download Modal */}
      <CVModal
        isOpen={cvModalOpen}
        onClose={() => setCvModalOpen(false)}
        language={language}
      />
    </div>
  );
}
